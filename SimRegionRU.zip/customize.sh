ui_print "Installing.."

resetprop gsm.sim.operator.iso-country "ru"