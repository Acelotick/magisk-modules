ui_print "Installing.."
echo "10" > /proc/sys/fs/lease-break-time;
echo "500" > /proc/sys/vm/dirty_expire_centisecs;
echo "1000" > /proc/sys/vm/dirty_writeback_centisecs;
echo "2048" > /sys/devices/virtual/bdi/179:0/read_ahead_kb;
ui_print "Ok!"