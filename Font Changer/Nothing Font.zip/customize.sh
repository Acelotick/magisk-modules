#!/system/bin/sh

ui_print "Создание копии старого шрифта.."
cp -f /system/fonts/DroidSans.ttf /data/adb/modules/fontnothing/system_fonts_backup/

ui_print "Монтируем систему для записи шрифта.."
mount -o rw,remount /system

ui_print "Копируем новый шрифт заместо старого.."
cp -f /data/adb/modules/fontnothing/system_fonts/nothing.ttf /system/fonts/DroidSans.ttf

ui_pring "Перезагружаемся.."
reboot