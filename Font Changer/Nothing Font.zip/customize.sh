#!/system/bin/sh

ui_print "Создание копии старого шрифта.."
cp -f /system/fonts/DroidSans.ttf /data/adb/modules/fontnothing/system_fonts_backup/

ui_print "Размонтируем систему для записи шрифта.."
mount -o rw,remount /system

ui_print "Монтируем файл шрифта для избежания неполадок.."
chmod 644 /system/fonts/DroidSans.ttf

ui_print "Удаляем старый шрифт.."
rm -f /system/fonts/DroidSans.ttf

ui_print "Копируем новый шрифт заместо старого.."
cp -f /data/adb/modules/fontnothing/system_fonts/nothing.ttf /system/fonts/DroidSans.ttf

ui_print " "
ui_print "Чтобы вернуть старый шрифт просто удалите модуль, система автоматически перезапустится."
ui_print " "
ui_print "Перезагрузитесь"