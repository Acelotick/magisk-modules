#!/system/bin/sh

mount -o rw,remount /system
chmod 644 /system/fonts/DroidSans.ttf

cp -f /data/adb/modules/fontnothing/system_fonts_backup/DroidSans.ttf /system/fonts/DroidSans.ttf

reboot